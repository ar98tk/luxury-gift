<!--begin::Footer-->
<div class="footer py-4 d-flex flex-lg-column" id="kt_footer">
    <!--begin::Container-->
    <div class="container-fluid d-flex flex-column flex-md-row align-items-center justify-content-between">
        <!--begin::Copyright-->
        <div class="text-dark order-2 order-md-1 mx-auto">
            <span class="text-muted fw-bold me-1">2022 © </span>
            <a href="#" class="text-gray-800 text-hover-primary">Luxury Gift</a>
        </div>
        <!--end::Copyright-->
    </div>
    <!--end::Container-->
</div>
<!--end::Footer-->
<?php /**PATH C:\Users\Abd El-Rahman\Desktop\luxury-gift\resources\views/partials/admin/footer.blade.php ENDPATH**/ ?>