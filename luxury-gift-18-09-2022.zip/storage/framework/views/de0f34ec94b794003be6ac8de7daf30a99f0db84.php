<?php $__env->startSection('content'); ?>
    <p class="fs-2tx fw-boldest text-center text-decoration-underline">Website Statistics</p>
    <!--begin::Post-->
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <!--begin::Container-->
        <div id="kt_content_container" class="container-xxl">
            <div class="row g-5 g-xl-8">
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abd El-Rahman\Desktop\luxury-gift\resources\views/admin/index.blade.php ENDPATH**/ ?>